/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.labswing;

/**
 *
 * @author student_user
 */
public class LabSwing {

    public static void main(String[] args) {
       GUI gui=new GUI();
       gui.setVisible(true);
    }
}
